#include "../lib/Distance.h"

Distance::Distance(void) {
    // cout << "Distance is being created" << endl;
}

Distance::~Distance(void) {
    // cout << "Distance is being deleted" << endl;
}

double Distance::calculateDistance(Vector *p, Vector *q) {
    return 0.0;
}

double Distance::calculateDistance(vector<double> * p, vector<double> * q) {
    return 0.0;
}